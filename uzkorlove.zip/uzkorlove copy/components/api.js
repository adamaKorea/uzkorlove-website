import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api/auth", // ✅ matches your backend
});

// Signup request
export const signupUser = async (data) => {
  return API.post("/signup", data);
};

// Login request
export const loginUser = async (data) => {
  return API.post("/login", data);
};
