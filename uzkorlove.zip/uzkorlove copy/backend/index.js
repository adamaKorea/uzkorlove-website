const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const protectedRoutes = require("./routes/protected");

require("dotenv").config();

const authRoutes = require("./routes/auth");
const protectedRoutes = require("./routes/protected"); // ✅ import protected routes

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/protected", protectedRoutes); // ✅ add protected routes here

// Health check
app.get("/", (req, res) => {
  res.send("Uzkorlove backend is running!");
});

// MongoDB connection and server start
const MONGO_URI = process.env.MONGO_URI;
if (!MONGO_URI) {
  console.error("❌ MongoDB URI not defined in .env");
  process.exit(1);
}

mongoose.connect(MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected");

    let PORT = parseInt(process.env.PORT) || 5000;

    const startServer = () => {
      const server = app.listen(PORT, () => {
        console.log(`🚀 Server running on port ${PORT}`);
      });

      server.on("error", (err) => {
        if (err.code === "EADDRINUSE") {
          console.warn(`⚠️ Port ${PORT} in use, trying port ${PORT + 1}...`);
          PORT++;
          startServer();
        } else {
          console.error("❌ Server error:", err);
        }
      });
    };

    startServer();
  })
  .catch(err => {
    console.error("❌ MongoDB connection error:", err);
  });
