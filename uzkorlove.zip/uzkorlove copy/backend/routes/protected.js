// routes/protected.js
const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");

// Middleware to verify JWT
const verifyToken = (req, res, next) => {
  // Token should be sent in Authorization header
  const token = req.headers["authorization"];
  if (!token) return res.status(401).json({ msg: "No token provided" });

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ msg: "Invalid token" });
    req.userId = decoded.id; // attach user ID from token to request
    next();
  });
};

// Example protected route
router.get("/dashboard", verifyToken, (req, res) => {
  res.json({ msg: "Welcome to the dashboard!", userId: req.userId });
});

module.exports = router;
