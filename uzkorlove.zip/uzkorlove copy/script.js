// -----------------------------
// BACKEND & CART
// -----------------------------
const BACKEND_URL = "http://localhost:5000/api";
const cartKey = "cart";

function getCart() {
  return JSON.parse(localStorage.getItem(cartKey)) || [];
}

function saveCart(cart) {
  localStorage.setItem(cartKey, JSON.stringify(cart));
  localStorage.setItem("cart-update", Date.now());
  updateMiniCart();
}

function updateMiniCart() {
  const cart = getCart();
  const cartCount = document.getElementById("cart-count");
  if (cartCount) cartCount.textContent = cart.length;
}

function addToCart(product) {
  const cart = getCart();
  cart.push(product);
  saveCart(cart);
  showNotification(`✅ ${product.name} mahsuloti korzinkaga qo'shildi!`);
}

document.getElementById("clear-cart")?.addEventListener("click", () => {
  if (confirm("Korzinkani tozalashni xohlaysizmi?")) {
    saveCart([]);
    renderCartPage();
  }
});

function renderCartPage() {
  const cartContainer = document.getElementById("cart-list");
  const cartTotal = document.getElementById("cart-total");
  if (!cartContainer) return;

  const cart = getCart();
  cartContainer.innerHTML = "";

  if (cart.length === 0) {
    cartContainer.innerHTML = "<p>Sizning korzinkangiz bo'sh.</p>";
    if (cartTotal) cartTotal.textContent = "";
    return;
  }

  cart.forEach((item, index) => {
    const li = document.createElement("li");
    li.textContent = `${item.name} - $${item.price.toFixed(2)}`;

    const removeBtn = document.createElement("button");
    removeBtn.textContent = "O‘chirish";
    removeBtn.style.marginLeft = "10px";
    removeBtn.style.padding = "3px 8px";
    removeBtn.style.backgroundColor = "#C49A36";
    removeBtn.style.color = "white";
    removeBtn.style.border = "none";
    removeBtn.style.borderRadius = "5px";
    removeBtn.style.cursor = "pointer";

    removeBtn.addEventListener("click", () => {
      cart.splice(index, 1);
      saveCart(cart);
      renderCartPage();
    });

    li.appendChild(removeBtn);
    cartContainer.appendChild(li);
  });

  const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);
  if (cartTotal) cartTotal.textContent = `Jami: $${totalPrice.toFixed(2)}`;
}

window.addEventListener("storage", (e) => {
  if (e.key === "cart-update") {
    renderCartPage();
    updateMiniCart();
  }
});

// -----------------------------
// MODAL HANDLING
// -----------------------------
const loginModal = document.getElementById("login-modal");
const signupModal = document.getElementById("signup-modal");

document.getElementById("open-login")?.addEventListener("click", () => loginModal.style.display = "flex");
document.getElementById("open-signup")?.addEventListener("click", () => signupModal.style.display = "flex");
document.getElementById("close-login")?.addEventListener("click", () => loginModal.style.display = "none");
document.getElementById("close-signup")?.addEventListener("click", () => signupModal.style.display = "none");

window.addEventListener("click", (e) => {
  if (e.target === loginModal) loginModal.style.display = "none";
  if (e.target === signupModal) signupModal.style.display = "none";
});

// -----------------------------
// PRODUCT BUTTONS
// -----------------------------
document.querySelectorAll(".product-item button").forEach((button) => {
  button.addEventListener("click", () => {
    const productCard = button.parentElement;
    const productName = productCard.querySelector("h3").textContent;
    const productPrice = parseFloat(productCard.querySelector("p").textContent.replace("$", ""));
    addToCart({ name: productName, price: productPrice });
  });
});

// -----------------------------
// FIREBASE MODULAR SETUP
// -----------------------------
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCDiLQErz2A4Vd_TaRi_mz0BvXgtF80stI",
  authDomain: "uzkorlove.firebaseapp.com",
  projectId: "uzkorlove",
  storageBucket: "uzkorlove.appspot.com",
  messagingSenderId: "922783288131",
  appId: "1:922783288131:web:201f0de69fae50c927bdf6",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Setup reCAPTCHA
window.recaptchaVerifier = new RecaptchaVerifier('recaptcha-container', {
  'size': 'invisible',
  'callback': (response) => { console.log("reCAPTCHA verified ✅"); }
}, auth);

// Send SMS
document.getElementById('send-code-btn')?.addEventListener('click', async () => {
  const phoneNumber = document.getElementById('phone').value.trim();
  if (!phoneNumber) { alert("Iltimos telefon raqam kiriting!"); return; }

  try {
    const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, window.recaptchaVerifier);
    window.confirmationResult = confirmationResult;
    alert(`✅ Kod yuborildi: ${phoneNumber}`);
  } catch (err) {
    console.error(err);
    alert("❌ Kod yuborilmadi: " + err.message);
  }
});

// Verify code
document.getElementById('verify-code-btn')?.addEventListener('click', async () => {
  const code = document.getElementById('code').value.trim();
  if (!code) { alert("Iltimos kodni kiriting!"); return; }

  try {
    const result = await window.confirmationResult.confirm(code);
    console.log("Phone verified:", result.user.uid);
    alert(`✅ Telefon raqam tasdiqlandi: UID ${result.user.uid}`);
  } catch (err) {
    console.error(err);
    alert("❌ Kod noto‘g‘ri yoki tasdiqlanmadi");
  }
});

// -----------------------------
// USER REGISTRATION
// -----------------------------
document.getElementById("register-btn")?.addEventListener("click", async (e) => {
  e.preventDefault();

  const name = document.getElementById("reg-name").value.trim();
  const surname = document.getElementById("reg-surname").value.trim();
  const email = document.getElementById("reg-email").value.trim();
  const loginId = document.getElementById("reg-login").value.trim();
  const password = document.getElementById("reg-password").value.trim();
  const address = document.getElementById("reg-address").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const code = document.getElementById("code").value.trim();

  if (!name || !surname || !loginId || !password || !address || !phone) {
    showNotification("Iltimos barcha maydonlarni to'ldiring!", "error");
    return;
  }

  if (!window.confirmationResult) {
    showNotification("Iltimos telefon raqamingizni tasdiqlang!", "error");
    return;
  }

  try {
    await window.confirmationResult.confirm(code);

    const res = await fetch(`${BACKEND_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, surname, email, loginId, password, address, phone }),
    });

    const data = await res.json();
    if (res.ok) {
      showNotification(`✅ Ro'yxatdan muvaffaqiyatli o'tdingiz! Xush kelibsiz, ${data.user.name}`);
      localStorage.setItem("token", data.token);
      signupModal.style.display = "none";
    } else {
      showNotification(data.message || "❌ Ro'yxatdan o'tishda xatolik yuz berdi", "error");
    }
  } catch (err) {
    console.error(err);
    showNotification("❌ Telefon raqam tasdiqlanmadi yoki kod noto‘g‘ri", "error");
  }
});

// -----------------------------
// USER LOGIN
// -----------------------------
document.getElementById("login-btn")?.addEventListener("click", async () => {
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value.trim();

  if (!email || !password) { showNotification("Iltimos email va parolni kiriting!", "error"); return; }

  try {
    const res = await fetch(`${BACKEND_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();
    if (res.ok) {
      showNotification(`✅ Kirish muvaffaqiyatli! Xush kelibsiz, ${data.user.name}`);
      localStorage.setItem("token", data.token);
      loginModal.style.display = "none";
      window.location.href = "products.html";
    } else {
      showNotification(data.message || "❌ Kirishda xatolik yuz berdi", "error");
    }
  } catch (err) {
    console.error(err);
    showNotification("❌ Xatolik yuz berdi. Iltimos qayta urinib ko'ring.", "error");
  }
});

// -----------------------------
// TOAST NOTIFICATIONS
// -----------------------------
function showNotification(message, type = "success", duration = 3000) {
  let container = document.getElementById("notification-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "notification-container";
    container.style.position = "fixed";
    container.style.top = "20px";
    container.style.right = "20px";
    container.style.zIndex = "10000";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.textContent = message;
  toast.style.padding = "10px 20px";
  toast.style.marginBottom = "10px";
  toast.style.borderRadius = "6px";
  toast.style.color = "#fff";
  toast.style.fontWeight = "500";
  toast.style.minWidth = "200px";
  toast.style.boxShadow = "0 2px 6px rgba(0,0,0,0.2)";
  toast.style.opacity = "0";
  toast.style.transform = "translateX(100%)";
  toast.style.transition = "all 0.5s ease";

  if (type === "success") toast.style.backgroundColor = "#4CAF50";
  else if (type === "error") toast.style.backgroundColor = "#f44336";
  else toast.style.backgroundColor = "#333";

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "1";
    toast.style.transform = "translateX(0)";
  }, 50);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(100%)";
    setTimeout(() => container.removeChild(toast), 500);
  }, duration);
}

// -----------------------------
// INITIALIZE
// -----------------------------
updateMiniCart();
renderCartPage();
