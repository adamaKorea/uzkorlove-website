// firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth,
  RecaptchaVerifier,
  signInWithPhoneNumber
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyCDiLQErz2A4Vd_TaRi_mz0BvXgtF80stI",
  authDomain: "uzkorlove.firebaseapp.com",
  projectId: "uzkorlove",
  storageBucket: "uzkorlove.firebasestorage.app",
  messagingSenderId: "922783288131",
  appId: "1:922783288131:web:201f0de69fae50c927bdf6",
  measurementId: "G-Y2690SGC5R"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// --- Phone verification ---
export function makeRecaptcha(containerId) {
  if (window.recaptchaVerifier) return window.recaptchaVerifier;
  window.recaptchaVerifier = new RecaptchaVerifier(containerId, { 'size':'invisible' }, auth);
  return window.recaptchaVerifier;
}

export async function sendPhoneCode(phoneNumber, containerId = 'recaptcha-container') {
  try {
    const appVerifier = makeRecaptcha(containerId);
    const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
    return { success: true, confirmationResult };
  } catch (err) {
    return { success: false, error: err };
  }
}

export async function verifyPhoneCode(confirmationResult, code) {
  try {
    const userCredential = await confirmationResult.confirm(code);
    return { success: true, user: userCredential.user };
  } catch (err) {
    return { success: false, error: err };
  }
}
