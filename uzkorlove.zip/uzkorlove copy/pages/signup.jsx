import React, { useState } from "react";
import { signupUser } from "../components/api"; // make sure this points to your actual API helper

export default function Signup() {
  const [name, setName] = useState(""); // optional if you want to ask for name
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!email || !password) {
      setMessage("❌ Iltimos barcha maydonlarni to'ldiring.");
      return;
    }

    try {
      const res = await signupUser({ name, email, password });

      // Save token & username to localStorage
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("username", res.data.user.name);

      setMessage("✅ Ro'yxatdan muvaffaqiyatli o'tdingiz! Kirish sahifasiga yo'naltirilasiz...");

      setEmail("");
      setPassword("");
      setName("");

      // Redirect after 1.5 seconds
      setTimeout(() => {
        window.location.href = "/products.html";
      }, 1500);
    } catch (err) {
      const errorMsg =
        err.response?.data?.msg ||
        err.response?.data?.message ||
        "❌ Ro'yxatdan o'tishda xatolik yuz berdi.";
      setMessage(errorMsg);
    }
  };

  return (
    <div className="auth-container" style={{ maxWidth: "400px", margin: "50px auto", padding: "20px", border: "1px solid #ddd", borderRadius: "8px" }}>
      <h2 style={{ textAlign: "center", marginBottom: "20px" }}>Ro'yxatdan o'tish</h2>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
        <input
          type="text"
          placeholder="Ismingiz"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          style={{ padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
        <input
          type="password"
          placeholder="Parol"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={{ padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
        <button type="submit" style={{ padding: "10px", backgroundColor: "#C49A36", color: "white", border: "none", borderRadius: "6px", cursor: "pointer" }}>
          Ro'yxatdan o'tish
        </button>
      </form>
      {message && <p style={{ marginTop: "15px", textAlign: "center", color: message.startsWith("✅") ? "green" : "red" }}>{message}</p>}
    </div>
  );
}
