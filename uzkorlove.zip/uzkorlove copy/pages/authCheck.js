// public/authCheck.js
window.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("token");
  if (!token) {
    alert("❌ You must log in first!");
    window.location.href = "/login.html"; // redirect to login
  }
});
