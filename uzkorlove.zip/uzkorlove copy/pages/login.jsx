import React, { useState } from "react";
import { loginUser } from "../components/api"; // make sure this points to your actual API helper

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!email || !password) {
      setMessage("❌ Iltimos email va parolni kiriting.");
      return;
    }

    try {
      const res = await loginUser({ email, password });

      // Save JWT token in localStorage
      localStorage.setItem("token", res.data.token);

      // Optional: save username to show in UI
      localStorage.setItem("username", res.data.user.name);

      setMessage("✅ Kirish muvaffaqiyatli!");
      
      // Redirect to products page after login
      window.location.href = "/products.html";
    } catch (err) {
      // Better error handling
      const errorMsg =
        err.response?.data?.msg ||
        err.response?.data?.message ||
        "❌ Kirish amalga oshmadi. Iltimos qayta urinib ko'ring.";
      setMessage(errorMsg);
    }
  };

  return (
    <div className="auth-container" style={{ maxWidth: "400px", margin: "50px auto", padding: "20px", border: "1px solid #ddd", borderRadius: "8px" }}>
      <h2 style={{ textAlign: "center", marginBottom: "20px" }}>Kirish</h2>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
        <input
          type="password"
          placeholder="Parol"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={{ padding: "10px", borderRadius: "6px", border: "1px solid #ccc" }}
        />
        <button type="submit" style={{ padding: "10px", backgroundColor: "#C49A36", color: "white", border: "none", borderRadius: "6px", cursor: "pointer" }}>
          Kirish
        </button>
      </form>
      {message && <p style={{ marginTop: "15px", textAlign: "center", color: message.startsWith("✅") ? "green" : "red" }}>{message}</p>}
    </div>
  );
}
